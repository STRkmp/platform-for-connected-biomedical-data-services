## Реализация универсального интерфейса для работы с очередями различных типов.

###Поддерживаемые типы очередей:
<br/>
FILE - файловая очередь<br/>
RMQ - очереди RabbitMQ (Pika)<br/>
KOMBU_RMQ - очереди RabbitMQ (Kombu)<br/>
KOMBU_REDIS - очереди Redis (Kombu)<br/>


###Примеры application.ini:
####Файловая очередь
<br/>
[QueueManager]<br/>
queue_type = FILE<br/>
auto_ack = True<br/>
queue_in = qmanager.test.queue_in<br/>
queue_out = qmanager.test.queue_out<br/>
queue_err = qmanager.test.queue_err<br/>
queue_timeout = 10<br/>

####Очередь Redis
<br/>
[QueueManager]<br/>
queue_type = KOMBU_REDIS<br/>
host = 192.168.56.205<br/>
port = 6379<br/>
virtual_host = vhost<br/>
exchange = redis_exchange<br/>
username = user<br/>
password = qwerty<br/>
auto_ack = True<br/>
queue_in = qmanager.test.queue_in<br/>
queue_out = qmanager.test.queue_out<br/>
queue_err = qmanager.test.queue_err<br/>
queue_timeout = 10<br/>

####Очередь RabbitMQ
<br/>
[QueueManager]<br/>
queue_type = KOMBU_RMQ<br/>
host = 192.168.56.205<br/>
port = 5672<br/>
virtual_host = vhost<br/>
exchange = rmq_exchange<br/>
username = user<br/>
password = qwerty<br/>
auto_ack = True<br/>
queue_in = qmanager.test.queue_in<br/>
queue_out = qmanager.test.queue_out<br/>
queue_err = qmanager.test.queue_err<br/>
queue_timeout = 10<br/>

