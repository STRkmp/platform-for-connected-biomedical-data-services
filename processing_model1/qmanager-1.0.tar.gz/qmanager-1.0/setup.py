from setuptools import setup
from os.path import join, dirname

setup(
    name='qmanager',
    version='1.0',
    packages=['qmanager', 'qmanager.impl'],
    install_requires=[
        'pika',
        'pydantic',
        'kombu'
    ],
    url='',
    license='',
    author='Bogdan Yudintsev',
    author_email='bogdan.u86@gmail.com',
    description='Wrapper for message queuing protocols',
    long_description=open(join(dirname(__file__), 'README.md')).read()
)
