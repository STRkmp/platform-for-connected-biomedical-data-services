from ..qmanager import QueueManager
from pydantic import BaseSettings
from typing import Callable
from threading import Lock
import os
import uuid
import time


THREAD_LOCK = Lock()


class FileQueueManager(QueueManager):
    def __init__(self, settings: BaseSettings, callback_func: Callable = None, auto_ack: bool = True,
                 auto_declare: bool = True, qid: str = None):
        QueueManager.__init__(self, settings, callback_func)
        self._auto_ack = auto_ack
        self._auto_declare = auto_declare
        self._qid = qid
        self._def_file_ext = '.bin'
        self.sort = True
        if auto_declare:
            self.init_queues()

    # todo: добавить префикс для многопоточной обработки
    def init_queues(self) -> bool:
        if self._auto_declare:
            try:
                if self.settings.queue_in is not None and not os.path.isdir(self.settings.queue_in):
                    os.mkdir(self.settings.queue_in)
                if self.settings.queue_out is not None and not os.path.isdir(self.settings.queue_out):
                    os.mkdir(self.settings.queue_out)
                if self.settings.queue_err is not None and not os.path.isdir(self.settings.queue_err):
                    os.mkdir(self.settings.queue_err)
                return True
            except Exception as error:
                self.logger.error(f"Queues initialization error:\n{error}")
        return False

    def publish(self, data: bytes, queue_name: str = None, headers: dict = None) -> bool:
        """" Сохранение данных в бинарный файл со случайным (UUID-based) именем """
        file_uuid = ""
        if queue_name is None:
            queue_name = self.queue_in
        if headers is not None:
            file_uuid = headers['businessId']
        else:
            file_uuid = str(uuid.uuid4())
        filepath = os.path.join(queue_name, f'{file_uuid}{self._def_file_ext}')
        self.logger.debug(f'Saving in {filepath}')
        # Записываем данные в байтах
        if not os.path.isfile(filepath):
            with open(filepath, 'wb') as file_data:
                file_data.write(data)
        else:
            self.logger.debug(f'File {filepath} is not unique')
            #raise FileExistsError(f'File {filepath} is not unique')
            return False
        return True

    def consume(self, queue_name: str = None) -> None:
        """ Сканирование папки на наличие новых файлов """
        if queue_name is None:
            queue_name = self.queue_in
        self.logger.debug(f'Scanning directory: {queue_name}...')
        while True:
            # todo: реализовать многопоточность, используя отдельные директории для разных потоков (qid)
            THREAD_LOCK.acquire()
            files = []
            if self.sort:
                files_iter = os.scandir(queue_name)
                files = sorted(files_iter, key=os.path.getmtime)
            else:
                files = os.scandir(queue_name)
            for f in files:
                if f.is_file() and f.name.endswith(self._def_file_ext):
                    self.logger.debug(f'Data found in: {f.path}')
                    file_reader = open(os.path.join(queue_name, f.name), 'rb')
                    data = file_reader.read()
                    file_reader.close()
                    if self._auto_ack:
                        self.logger.debug(f'Removing from queue: {f.path}')
                        os.remove(f.path)
                    try:
                        self.callback(data, {'businessId': f.name})
                    except Exception as error:
                        self.logger.error(f'Callback event error while reading {f.path}:\n{error}')
                        self.on_error_callback(data, {'businessId': f.name})
            THREAD_LOCK.release()
            time.sleep(self.settings.queue_timeout)
