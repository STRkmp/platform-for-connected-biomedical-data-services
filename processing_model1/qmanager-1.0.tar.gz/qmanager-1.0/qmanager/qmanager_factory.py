from typing import Optional
from .qmanager import QueueManager
from .impl.file_qmanager import FileQueueManager
from .impl.rmq_qmanager import RmqQueueManager
from .impl.kombu_rmq_qmanager import KombuRmqQueueManager
from .impl.kombu_redis_qmanager import KombuRedisQueueManager
from pydantic import BaseSettings
from typing import Callable


class QueueManagerFactory:
    def __init__(self, settings: BaseSettings):
        self.instance = None
        self.settings = settings

    def get_instance(self, callback_func: Callable = None) -> Optional[QueueManager]:
        if self.settings.queue_type == 'FILE':
            self.instance = FileQueueManager(self.settings, callback_func, auto_ack=self.settings.auto_ack)
            return self.instance
        elif self.settings.queue_type == 'RMQ':
            self.instance = RmqQueueManager(self.settings, callback_func, auto_ack=self.settings.auto_ack)
            return self.instance
        elif self.settings.queue_type == 'KOMBU_RMQ':
            self.instance = KombuRmqQueueManager(self.settings, callback_func, auto_ack=self.settings.auto_ack)
            return self.instance
        elif self.settings.queue_type == 'KOMBU_REDIS':
            self.instance = KombuRedisQueueManager(self.settings, callback_func, auto_ack=self.settings.auto_ack)
            return self.instance
        return None
