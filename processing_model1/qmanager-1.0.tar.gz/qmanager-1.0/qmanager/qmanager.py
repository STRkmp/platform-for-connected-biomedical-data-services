from abc import ABC, abstractmethod     # подключаем инструменты для создания абстрактных классов
from pydantic import BaseSettings
from typing import Callable, Optional
import logging
import logging.config


class QueueManager(ABC):
    logger = None

    def __init__(self, settings: BaseSettings, callback_func: Callable = None, on_error_callback_func: Callable = None):
        self.init_logger()
        self.settings = settings
        self.queue_in = settings.queue_in
        self.queue_out = settings.queue_out
        self.queue_err = settings.queue_err
        self.callback = self.default_callback
        self.on_error_callback = self.default_on_error_callback
        if callback_func is not None:
            self.callback = callback_func
        elif self.queue_out is None:
            self.callback = self.none_callback
        if on_error_callback_func is not None:
            self.on_error_callback = on_error_callback_func
        elif self.queue_err is None:
            self.on_error_callback = self.none_callback

    def init_logger(self) -> None:
        try:
            logging.config.fileConfig('logger.ini')
            self.logger = logging.getLogger('qmanager')
        except:
            logging.basicConfig(filename='qmanager.log', level=logging.DEBUG,
                                format='%(asctime)s %(module)s_%(thread)d: %(message)s')
            self.logger = logging.getLogger()

    @abstractmethod
    def init_queues(self) -> bool:
        pass

    #@staticmethod
    @abstractmethod
    def publish(self, data: bytes, queue_name: str = None, headers: dict = None) -> bool:
        pass

    @abstractmethod
    def consume(self, queue_name: str = None) -> None:
        pass

    def default_callback(self, data: bytes, headers: dict = None) -> None:
        self.publish(data=data, queue_name=self.queue_out, headers=headers)

    def default_on_error_callback(self, data: bytes, headers: dict = None) -> None:
        self.publish(data=data, queue_name=self.queue_err, headers=headers)

    def none_callback(self, data: bytes, headers: dict = None) -> None:
        pass
